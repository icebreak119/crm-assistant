import { useState, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import { Search, Plus, Users, Download } from 'lucide-react';
import { toast } from 'sonner';
import { format } from 'date-fns';
import { useCrm } from '@/hooks/useCrm';
import { useI18n } from '@/hooks/useI18n';
import { downloadCSV } from '@/lib/csv';
import CustomerCard from '@/components/CustomerCard';
import ListSentinel from '@/components/ListSentinel';
import { useInfiniteList } from '@/hooks/useInfiniteList';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';
import { motion, AnimatePresence } from 'framer-motion';

export default function CustomersPage() {
  const { customers, groups } = useCrm();
  const navigate = useNavigate();
  const { t } = useI18n();
  const [keyword, setKeyword] = useState('');
  const [activeGroup, setActiveGroup] = useState('all');

  const filtered = useMemo(() => {
    let result = customers;
    if (activeGroup !== 'all') {
      result = result.filter((c) => c.groupId === activeGroup);
    }
    if (keyword.trim()) {
      const kw = keyword.trim().toLowerCase();
      result = result.filter(
        (c) =>
          c.name.toLowerCase().includes(kw) ||
          (c.company?.toLowerCase().includes(kw) ?? false) ||
          c.phone.includes(kw),
      );
    }
    return [...result].sort((a, b) => {
      if (a.isStarred !== b.isStarred) return a.isStarred ? -1 : 1;
      return b.createdAt - a.createdAt;
    });
  }, [customers, activeGroup, keyword]);

  const { visibleItems, hasMore, sentinelRef, visibleCount, totalCount: listTotalCount } = useInfiniteList(filtered);
  const totalCount = customers.length;

  const handleExport = () => {
    const headers = [
      t('csv.name'),
      t('csv.gender'),
      t('csv.phone'),
      t('csv.company'),
      t('csv.companyAddress'),
      t('csv.intendedProduct'),
      t('csv.tags'),
      t('csv.group'),
      t('csv.starred'),
      t('csv.description'),
      t('csv.remark'),
      t('csv.createdAt'),
    ];
    const groupName = (gid: string) => groups.find((g) => g.id === gid)?.name ?? '';
    const exportRows = filtered.map((c) => [
      c.name,
      c.gender === 'female' ? t('common.female') : t('common.male'),
      c.phone,
      c.company ?? '',
      c.companyAddress ?? '',
      c.intendedProduct ?? '',
      (c.tags ?? []).join('; '),
      groupName(c.groupId),
      c.isStarred ? t('common.yes') : t('common.no'),
      c.description ?? '',
      c.remark ?? '',
      format(new Date(c.createdAt), 'yyyy-MM-dd'),
    ]);
    downloadCSV(`${t('customers.exportName')}_${format(new Date(), 'yyyyMMdd')}.csv`, headers, exportRows);
    toast.success(t('customers.exported', { count: filtered.length }));
  };

  return (
    <div className="min-h-screen">
      {/* 搜索 + 分组Tab */}
      <div className="sticky top-0 z-40 border-b border-border bg-background/95 backdrop-blur-md">
        <div className="px-4 pt-4 pb-2">
          <h1 className="mb-3 text-xl font-bold">{t('customers.title')}</h1>
          <div className="flex gap-2">
            <div className="relative flex-1">
              <Search className="pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" />
              <Input
                type="search"
                value={keyword}
                onChange={(e) => setKeyword(e.target.value)}
                placeholder={t('customers.search')}
                className="bg-muted pl-9"
              />
            </div>
            <Button variant="outline" size="icon" className="shrink-0" onClick={handleExport} aria-label={t('common.export')}>
              <Download className="size-4" />
            </Button>
          </div>
        </div>
        <div className="no-scrollbar flex gap-2 overflow-x-auto px-4 pb-2">
          <button
            onClick={() => setActiveGroup('all')}
            className={cn(
              'shrink-0 rounded-full px-4 py-2 text-sm transition-colors',
              activeGroup === 'all'
                ? 'bg-primary text-primary-foreground'
                : 'border border-border bg-background text-muted-foreground',
            )}
          >
            {t('common.all')} ({totalCount})
          </button>
          {groups.map((g) => {
            const count = customers.filter((c) => c.groupId === g.id).length;
            return (
              <button
                key={g.id}
                onClick={() => setActiveGroup(g.id)}
                className={cn(
                  'shrink-0 rounded-full px-4 py-2 text-sm transition-colors',
                  activeGroup === g.id
                    ? 'bg-primary text-primary-foreground'
                    : 'border border-border bg-background text-muted-foreground',
                )}
              >
                {g.name} ({count})
              </button>
            );
          })}
        </div>
      </div>

      {/* 客户列表 */}
      <AnimatePresence mode="wait">
        <motion.div
          key={activeGroup}
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.15, ease: 'easeOut' }}
          className="space-y-3 p-4"
        >
          {filtered.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-20 text-center">
              <div className="mb-4 flex size-16 items-center justify-center rounded-full bg-muted">
                <Users className="size-8 text-muted-foreground" />
              </div>
              <p className="mb-1 text-muted-foreground">
                {keyword || activeGroup !== 'all'
                  ? t('customers.empty.noMatch')
                  : t('customers.empty.noData')}
              </p>
              <p className="mb-4 text-sm text-muted-foreground">
                {t('customers.empty.addFirst')}
              </p>
              <Button onClick={() => navigate('/customers/new')}>
                <Plus className="size-4" />
                {t('customers.add')}
              </Button>
            </div>
          ) : (
            <>
              {visibleItems.map((c, i) => (
                <motion.div
                  key={c.id}
                  initial={{ opacity: 0, y: 12 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.2, delay: Math.min(i * 0.03, 0.3), ease: 'easeOut' }}
                >
                  <CustomerCard customer={c} />
                </motion.div>
              ))}
              <ListSentinel sentinelRef={sentinelRef} hasMore={hasMore} visibleCount={visibleCount} totalCount={listTotalCount} />
            </>
          )}
        </motion.div>
      </AnimatePresence>
    </div>
  );
}
