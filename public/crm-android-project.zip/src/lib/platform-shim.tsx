import { type ReactNode } from 'react';

/**
 * 平台 SDK 替代模块
 * 用于 Capacitor 独立构建，替代 @lark-apaas/client-toolkit-lite 的运行时导出
 * 通过 vite.config.capacitor.ts 的 alias 重定向到此文件
 */

// scopedStorage → 直接包装 localStorage（独立运行不需要 appId 隔离）
export const scopedStorage = {
  getItem: (key: string): string | null => {
    try {
      return localStorage.getItem(key);
    } catch {
      return null;
    }
  },
  setItem: (key: string, value: string): void => {
    try {
      localStorage.setItem(key, value);
    } catch {
      // 忽略存储满或隐私模式错误
    }
  },
  removeItem: (key: string): void => {
    try {
      localStorage.removeItem(key);
    } catch {
      // 忽略
    }
  },
};

// AppContainer → 透传组件（原平台 SDK 提供应用容器，独立运行不需要）
export function AppContainer({ children }: { children: ReactNode }) {
  return <>{children}</>;
}

// ErrorRender → 基础错误显示（原平台 SDK 提供错误渲染，这里用内联样式确保无 CSS 依赖）
export function ErrorRender({ error }: { error: Error; resetErrorBoundary?: () => void }) {
  return (
    <div style={{
      padding: '24px',
      textAlign: 'center',
      minHeight: '100vh',
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      justifyContent: 'center',
    }}>
      <h2 style={{ color: '#c0392b', fontSize: '20px', marginBottom: '8px' }}>
        应用出错了
      </h2>
      <p style={{ color: '#666', fontSize: '14px' }}>
        {error.message}
      </p>
    </div>
  );
}
