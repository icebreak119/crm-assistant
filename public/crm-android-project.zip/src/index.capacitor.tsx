import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import { HashRouter } from 'react-router-dom';
import { ErrorBoundary } from 'react-error-boundary';
import { AppContainer, ErrorRender } from '@lark-apaas/client-toolkit-lite';
import App from './app';
import './index.css';

/**
 * Capacitor 入口文件
 * 与 src/index.tsx 的区别：使用 HashRouter 替代 BrowserRouter
 * Capacitor 的 file:// 协议不支持 HTML5 history API，必须用 HashRouter
 */
createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <HashRouter>
      <AppContainer>
        <ErrorBoundary
          fallbackRender={({ error, resetErrorBoundary }) => (
            <ErrorRender error={error} resetErrorBoundary={resetErrorBoundary} />
          )}
        >
          <App />
        </ErrorBoundary>
      </AppContainer>
    </HashRouter>
  </StrictMode>,
);
